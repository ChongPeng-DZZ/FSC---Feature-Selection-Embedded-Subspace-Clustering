clc;    clear;  close all;  warning off

addpath codes

filename = 'YaleBCrop025';
load(strcat(filename,'.mat'))

rho = 2.0;  kappa = 1.2;    alpha = 0.4;    M = 300;    toler = 1e-3;   maxiter = 500;  % NN
% rho = 3.0;  kappa = 1.15;   alpha = 0.6;    M = 300;    toler = 1e-3;   maxiter = 500;  % LD
nSet = [2 3 5 8 10];


Medacc = zeros(length(nSet),1);
Avgacc = Medacc;
for i = 1:length(nSet)
    n = nSet(i);
    idx = Ind{n};
    
    gnd = s{n};
    
    totacc = 0;
    avgacc = 0;
    Acc = zeros(size(idx,1),1);
    for j = 1 : size(idx,1)
        
        A = [];
        for p = 1 : n
            A = [A Y(:,:,idx(j,p))];
        end
        
        A = mat2gray(A);
        
        [Z,pp] = FSC_NN(A,alpha,M,rho,kappa,maxiter,toler);
%         [Z,pp] = FSC_LD(A,alpha,M,rho,kappa,maxiter,toler);
        
        acc = KSC_Acc(Z,2,n,gnd);
        
        Acc(j) = acc;
        totacc = totacc+acc;
        avgacc = totacc/j;
        medacc = median(Acc(1:j));
        
        fprintf(1,'#Obj = %3d(%3d/%3d), acc: %6.4f, avgacc: %6.4f, medacc: %6.4f\n',n,j,size(idx,1),acc,avgacc,medacc);
       
    end
    Medacc(i) = median(Acc);
    Avgacc(i) = avgacc;

end

fclose all;
