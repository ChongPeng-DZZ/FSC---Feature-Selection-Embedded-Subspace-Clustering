clc;    clear;  close all;  warning off

addpath codes

% filename = 'Hopkins155';
% data = load_motion_data(1);
% data(140) = [];

load('Hopkins155.mat')


% rho = 0.005;    kappa = 1.05;   alpha = 0.00025;    M = 25;     toler = 1e-3;   maxiter = 500;  % NN
rho = 0.005;    kappa = 1.03;   alpha = 0.00030;   M = 25;     toler = 1e-3;   maxiter = 500;  % LD


Acc = zeros(length(data),1);
LAcc = Acc;

for t = 1 : length(data)
    A = data(t).X;
    gnd = data(t).ids;
    K = max(gnd);
        
%         [Z,pp] = FSC_NN(A,alpha,M,rho,kappa,maxiter,toler);
        [Z,pp] = FSC_LD(A,alpha,M,rho,kappa,maxiter,toler);
        
        acc = KSC_Acc(Z,2,K,gnd);
        
        Acc(t) = acc;
        LAcc(t) = K;
        avgacc2obj = max(0,mean(Acc(LAcc==2)));
        medacc2obj = max(0,median(Acc(LAcc==2)));
        avgacc3obj = max(0,mean(Acc(LAcc==3)));
        medacc3obj = max(0,median(Acc(LAcc==3)));
        
        avgacc = max(0,mean(Acc(LAcc~=0)));
        medacc = max(0,median(Acc(LAcc~=0)));
        
        fprintf(1,'#Obj = %3d(%3d/%3d), acc: %6.4f, avgacc(2): %6.4f, avgacc(3): %6.4f, avgacc(all): %6.4f\n',K,sum(LAcc==K),35*(K==3)+120*(K==2),acc,avgacc2obj,avgacc3obj,avgacc);
    
end

fclose all;

